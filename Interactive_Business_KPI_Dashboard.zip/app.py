import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(page_title="Interactive Business KPI Dashboard", layout="wide")
st.title("Interactive Business KPI Dashboard")
st.caption("Demo dataset generated for practice. Replace it with your own business data before presenting real results.")

uploaded = st.sidebar.file_uploader("Upload your CSV (optional)", type=["csv"])
default_path = "sample_business_sales.csv"
try:
    data = pd.read_csv(uploaded) if uploaded else pd.read_csv(default_path)
except Exception as e:
    st.error(f"Could not load data: {e}")
    st.stop()

required = {"Order_Date","Region","Category","Revenue","Customer_ID","Order_ID","Marketing_Spend","Churned"}
missing = required - set(data.columns)
if missing:
    st.error("Missing required columns: " + ", ".join(sorted(missing)))
    st.stop()

data["Order_Date"] = pd.to_datetime(data["Order_Date"], errors="coerce")
data["Revenue"] = pd.to_numeric(data["Revenue"], errors="coerce").fillna(0)
data["Marketing_Spend"] = pd.to_numeric(data["Marketing_Spend"], errors="coerce").fillna(0)
data["Churned"] = data["Churned"].astype(str).str.lower().isin(["true","1","yes"])
data = data.dropna(subset=["Order_Date"])

st.sidebar.header("Filters")
regions = st.sidebar.multiselect("Region", sorted(data["Region"].dropna().unique()), default=sorted(data["Region"].dropna().unique()))
categories = st.sidebar.multiselect("Category", sorted(data["Category"].dropna().unique()), default=sorted(data["Category"].dropna().unique()))
min_date, max_date = data["Order_Date"].min().date(), data["Order_Date"].max().date()
date_range = st.sidebar.date_input("Date range", value=(min_date,max_date), min_value=min_date, max_value=max_date)
filtered = data[data["Region"].isin(regions) & data["Category"].isin(categories)]
if isinstance(date_range, tuple) and len(date_range)==2:
    filtered = filtered[filtered["Order_Date"].dt.date.between(date_range[0], date_range[1])]

revenue = filtered["Revenue"].sum()
orders = filtered["Order_ID"].nunique()
customers = filtered["Customer_ID"].nunique()
cac = filtered["Marketing_Spend"].sum()/max(customers,1)
aov = revenue/max(orders,1)
churn_rate = filtered["Churned"].mean()*100 if len(filtered) else 0

c1,c2,c3,c4 = st.columns(4)
c1.metric("Total Revenue", f"₹{revenue:,.0f}")
c2.metric("Customer Acquisition Cost (proxy)", f"₹{cac:,.0f}")
c3.metric("Churn Rate", f"{churn_rate:.1f}%")
c4.metric("Average Order Value", f"₹{aov:,.0f}")

left,right = st.columns(2)
with left:
    monthly = filtered.assign(Month=filtered["Order_Date"].dt.to_period("M").dt.to_timestamp()).groupby("Month",as_index=False)["Revenue"].sum()
    st.subheader("Monthly revenue trend")
    st.plotly_chart(px.area(monthly,x="Month",y="Revenue",markers=True,title="Revenue by month"),use_container_width=True)
with right:
    region = filtered.groupby("Region",as_index=False)["Revenue"].sum().sort_values("Revenue",ascending=False)
    st.subheader("Revenue by region")
    st.plotly_chart(px.bar(region,x="Region",y="Revenue",color="Revenue",title="Regional comparison"),use_container_width=True)

left,right = st.columns(2)
with left:
    cat = filtered.groupby("Category",as_index=False)["Revenue"].sum()
    st.subheader("Category drill-down")
    st.plotly_chart(px.treemap(filtered,path=["Category","Product"],values="Revenue",title="Category → Product"),use_container_width=True)
with right:
    st.subheader("Order details")
    st.dataframe(filtered.sort_values("Order_Date",ascending=False),use_container_width=True,hide_index=True)

st.subheader("KPI definitions")
st.markdown("""
- **Revenue:** sum of order revenue.
- **CAC proxy:** marketing spend divided by unique customers in the filtered dataset. This is an educational proxy, not a finance-validated CAC calculation.
- **Churn rate:** percentage of rows marked `Churned=True` in the filtered dataset. For a production dashboard, calculate churn from a customer-period cohort.
- **Average Order Value:** revenue divided by distinct orders.
""")
st.download_button("Download filtered data as CSV", filtered.to_csv(index=False).encode("utf-8"), "filtered_business_data.csv", "text/csv")
