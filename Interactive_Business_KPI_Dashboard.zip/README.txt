INTERACTIVE BUSINESS KPI DASHBOARD

Files:
- app.py: Streamlit dashboard app
- sample_business_sales.csv: generated demo data (720 order rows)
- requirements.txt: required Python packages

Run on a computer with Python:
1. Install Python if needed.
2. Open Command Prompt/Terminal in this folder.
3. Run: pip install -r requirements.txt
4. Run: streamlit run app.py
5. The dashboard opens in your browser.

Dashboard features:
- KPI cards: revenue, CAC proxy, churn rate, average order value
- Monthly revenue area chart
- Regional revenue comparison
- Category-to-product treemap
- Date, region and category filters
- Filtered-data CSV download

Important:
This is a practice project using synthetic sample data, not real company data.
CAC is labelled as a proxy and churn is calculated from demo row-level flags.
